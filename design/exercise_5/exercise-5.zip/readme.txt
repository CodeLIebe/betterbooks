﻿Browser: Chrome

______________________________________

              Authors
______________________________________

Elisabeth Fughe: Mat.-Nr. 5263769
mostly Exercise 1 a
Amer El-Ankah: Mat.-Nr. 5750818
mostly Exercise 1 b
______________________________________

              Source
______________________________________

-------------
--General
-------------
Lorem Ipsum Text Generator: http://www.loremipsum.de/
Bootstrap Documentation : https://getbootstrap.com/docs/4.1/getting-started/introduction/
-------------
-- Fonts
-------------
Better Saturday - Free for personal use - https://befonts.com/better-saturday-script-font.html
DJ Holly Jolly - Free for personal use - https://www.dafont.com/djb-holly-jolly-bgolly.font
Work Sans - Free use under Open Font License - https://fonts.google.com/specimen/Work+Sans
-------------
--Images on website
-------------
Book Cover (Leaves): https://www.freepik.com/free-vector/wedding-photography-book-with-watercolor-leaves_2956011.htm - Free Psd - Author: Freepik - Last visited date: 5.12.2018
Book Cover (Mock up - square): https://www.freepik.com/free-psd/square-book-mockup_1435914.htm - Free Psd - Author: Yeven_popov/Freepik - Last visited date: 5.12.2018
Open book (Bike riders): https://www.freepik.com/free-psd/stationery-mockup-with-open-bool_1532485.htm - Free Psd - Author: Freepik - Last visited date: 5.12.2018
Feather used in logo and icon: https://www.freepik.com/free-vector/sketchy-feathers-pack_759744.htm - Free Psd - Author: Freepik - Last visited date: 5.12.2018
- other icons and images self-made using Illustrator
--------------------------
--Images in Mock ups
--------------------------
Map in Mockups: https://www.freepik.com/free-vector/map-pin-in-a-map_714013.htm - Free Psd - Author: Illustrations - Last visited date: 5.12.2018
Book Cover (Travel & The end of the boundaries) used in mock ups: https://www.freepik.com/free-psd/book-cover-template_863591.htm - Free Psd - Author: Qeaql-studio/Freepik - Last visited date: 5.12.2018
Book Cover used in mockups: https://www.freepik.com/free-psd/book-cover-mockup-of-two_2740407.htm - Free Psd - Author: Freepik - Last visited date: 5.12.2018
-------------
--Code Pen/ JS Fiddle
-------------
Make dropup parent clickable link - open source code from Code Pen by Pascale Beier - https://codepen.io/PascaleBeier/pen/BdgPre - Author: Pascale Beier - Last visited date: 5.12.2018
JavaScript Search Filter - https://codepen.io/jsartisan/pen/wKORYL - Last visited date: 30.12.2018
JavaScript Price Slider - http://jsfiddle.net/bZmJ8/33/ - Last visited date: 05.01.2019
-------------
--Tutorials
-------------
https://www.youtube.com/watch?v=yafNKsqZ4cA - Last visited date: 5.12.2018
https://lerneprogrammieren.de/tutorial-3-quiz-programmieren/ - Last visited date: 5.12.2018
-------------
--Quiz Answer
-------------
correct answers: 3,2,3
---------------
--Other sources
---------------
Tritanomalie: https://www.brillen-sehhilfen.de/auge/tritanomalie-blauschsehschwaeche.php - Last visited date: 19.12.2018
Deuteranopie: https://www.brillen-sehhilfen.de/auge/deuteranopie-gruenblindheit.php - Last visited date: 19.12.2018
Presbyopie: https://www.sehtestbilder.de/weitsichtigkeit/altersweitsichtigkeit-presbyopie.php - Last visited date: 19.12.2018
Tool zum Simulieren von Farbschwächen: http://colororacle.org - Last visited date: 19.12.2018
Informationen zum Crud Interface: https://stackify.com/what-are-crud-operations/ - Last visited date: 07.01.2019

